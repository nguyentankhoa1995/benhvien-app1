//
//  ThumbImageModels.h
//  benhvien-app1
//
//  Created by 507-8 on 8/21/17.
//  Copyright © 2017 507-8. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThumbImageModels : NSObject

@property (strong, nonatomic) NSString *hospitalDescipton;

@end
