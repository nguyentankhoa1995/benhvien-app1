//
//  UITextField+Padding.h
//  benhvien-app-objc
//
//  Created by HaoLe on 7/12/17.
//  Copyright © 2017 HaoLe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Padding)

@end
