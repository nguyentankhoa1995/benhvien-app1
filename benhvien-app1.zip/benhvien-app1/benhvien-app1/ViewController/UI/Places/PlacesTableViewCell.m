//
//  PlacesTableViewCell.m
//  benhvien-app1
//
//  Created by 507-8 on 9/11/17.
//  Copyright © 2017 507-8. All rights reserved.
//

#import "PlacesTableViewCell.h"

@implementation PlacesTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
