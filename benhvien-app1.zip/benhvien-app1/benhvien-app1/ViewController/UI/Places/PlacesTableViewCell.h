//
//  PlacesTableViewCell.h
//  benhvien-app1
//
//  Created by 507-8 on 9/11/17.
//  Copyright © 2017 507-8. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlacesTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cityNameLabel;

@end
