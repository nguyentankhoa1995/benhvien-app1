//
//  PhoneNumberCell.h
//  benhvien-app1
//
//  Created by 507-8 on 7/31/17.
//  Copyright © 2017 507-8. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HLTableViewCell.h"

@interface PhoneNumberCell : HLTableViewCell

@property (weak, nonatomic) IBOutlet UILabel *hospitalPhoneLabel;

@end
