//
//  ThumbImageTableViewCell.h
//  
//
//  Created by 507-8 on 7/31/17.
//
//

#import <UIKit/UIKit.h>
#import "HLTableViewCell.h"

@interface ThumImageTableViewCell : HLTableViewCell

@property (strong,nonatomic) NSString *tableViewHeaderIndentifier;
@property (weak, nonatomic) IBOutlet UILabel *hospitalDesciptionLabel;

@end
