//
//  AppDelegate.h
//  benhvien-app1
//
//  Created by 507-8 on 7/28/17.
//  Copyright © 2017 507-8. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <OCGoogleDirectionsAPI/OCGoogleDirectionsAPI.h>
#import "AppInfoViewController.h"
#import "BaseTabBarController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

- (void)setupHomeScreen1;
- (void)setupFirstLoginScreen;

@end

